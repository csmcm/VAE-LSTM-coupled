import numpy as np
import torch
import torch.nn as nn
import pandas as pd
import matplotlib as plt
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import ticker
from sklearn import linear_model
from sklearn.preprocessing import MinMaxScaler
import math, time
from sklearn.metrics import mean_squared_error
from torch.utils.data import DataLoader

config = {
    "font.family": 'serif',
    "font.size": 15,
    "mathtext.fontset": 'stix',
    "font.serif": ['Times New Roman'],
}
device = torch.device("cuda")	# 使用gpu训练
device = torch.device("cuda:0")	# 当电脑中有多张显卡时，使用第一张显卡
#filepath = 'G:\\xiangmu\\1\\new_month_data\\fake_59-66_1vn.xlsx'
#filepath = 'G:\\xiangmu\\1\\new_month_data\\rainfall_and_spring_flow.xlsx'
#filepath = 'G:\\xiangmu\\1\\data\\71-06\\71-06.xlsx'
filepath = 'G:\\xiangmu\\1\\new_month_data\\fake_71-06_1v4.xlsx'
#filepath = 'G:\\xiangmu\\1\\data\\07-19\\07-19.xlsx'
#filepath = 'G:\\xiangmu\\1\\new_month_data\\fake_07-19_1vn.xlsx'
data = pd.read_excel(filepath)
pre_months = 12
rainFall_YangQuan = data[['阳泉降水']].copy()
rainFall_PingDing = data[['平定降水']].copy()
rainFall_YuXian = data[['盂县降水']].copy()
rainFall_ShouYang = data[['寿阳降水']].copy()
rainFall_XiYang = data[['昔阳降水']].copy()
rainFall_HeShun = data[['和顺降水']].copy()
rainFall_ZuoQuan = data[['左权降水']].copy()
spring_Flow = data[['泉水流量(m3/s)']].copy()

# 进行不同的数据缩放，将数据缩放到-1和1之间，归一化操作
scaler1 = MinMaxScaler(feature_range=(-1, 1))
scaler2 = MinMaxScaler(feature_range=(-1, 1))
scaler3 = MinMaxScaler(feature_range=(-1, 1))
scaler4 = MinMaxScaler(feature_range=(-1, 1))
scaler5 = MinMaxScaler(feature_range=(-1, 1))
scaler6 = MinMaxScaler(feature_range=(-1, 1))
scaler7 = MinMaxScaler(feature_range=(-1, 1))
scaler8 = MinMaxScaler(feature_range=(-1, 1))
scaler9 = MinMaxScaler(feature_range=(-1, 1))
scaler10 = MinMaxScaler(feature_range=(-1, 1))
rainFall_YangQuan['阳泉降水'] = scaler1.fit_transform(rainFall_YangQuan['阳泉降水'].values.reshape(-1, 1))
rainFall_PingDing['平定降水'] = scaler2.fit_transform(rainFall_PingDing['平定降水'].values.reshape(-1, 1))
rainFall_YuXian['盂县降水'] = scaler3.fit_transform(rainFall_YuXian['盂县降水'].values.reshape(-1, 1))
rainFall_ShouYang['寿阳降水'] = scaler4.fit_transform(rainFall_ShouYang['寿阳降水'].values.reshape(-1, 1))
rainFall_XiYang['昔阳降水'] = scaler5.fit_transform(rainFall_XiYang['昔阳降水'].values.reshape(-1, 1))
rainFall_HeShun['和顺降水'] = scaler6.fit_transform(rainFall_HeShun['和顺降水'].values.reshape(-1, 1))
rainFall_ZuoQuan['左权降水'] = scaler7.fit_transform(rainFall_ZuoQuan['左权降水'].values.reshape(-1, 1))
spring_Flow['泉水流量(m3/s)'] = scaler8.fit_transform(spring_Flow['泉水流量(m3/s)'].values.reshape(-1, 1))
#year_flow['年份']= scaler9.fit_transform(year_flow['年份'].values.reshape(-1, 1))
#month_flow['月份']= scaler10.fit_transform(month_flow['月份'].values.reshape(-1, 1))
# print(spring_Flow['泉水流量(m3/s)'].shape)
# print(spring_Flow.info())
# 数据集制作
# 用各地区降水来预测泉水流量
# lookback表示观察的跨度
def split_data_x(features, lookback):
    data_raw = features.to_numpy()
    data = []
    # 将数据按 lookback 划分成数据点，每个数据点包含 lookback 行和数据特征数量加一列的列向量
    for index in range(len(data_raw) - lookback):
        data.append(data_raw[index: index + lookback])
    data = np.array(data);
    # print(type(data))
    # 按照8:2进行训练集、测试集划分
    test_set_size = int(np.round(0.33* data.shape[0]))
    train_set_size = data.shape[0] - (test_set_size)
    #x_train = data[:train_set_size, :-1,1:]#7特征
    #x_test = data[train_set_size:, :-1,1:]
    x_train = data[:train_set_size, :-1,0:]#8特征
    x_test = data[train_set_size:, :-1,0:]
    y_train = data[:train_set_size,-1,0:1]
    y_test = data[train_set_size:,-1,0:1]
    return [x_train, x_test,y_train,y_test]
lookback = 12

# 合并所有特征
features_x = pd.concat(
    [spring_Flow,rainFall_YangQuan, rainFall_PingDing, rainFall_YuXian, rainFall_ShouYang, rainFall_XiYang, rainFall_HeShun,
     rainFall_ZuoQuan], axis=1)

x_train, x_test,y_train,y_test = split_data_x(features_x, lookback)
#y_train, y_test = split_data_y(spring_Flow, lookback)
print('x_train.shape = ', x_train.shape)
print('y_train.shape = ', y_train.shape)
print('x_test.shape = ', x_test.shape)
print('y_test.shape = ', y_test.shape)

x_train = torch.from_numpy(x_train).type(torch.Tensor)
x_test = torch.from_numpy(x_test).type(torch.Tensor)
y_train_lstm = torch.from_numpy(y_train).type(torch.Tensor)  #作为label
y_test_lstm = torch.from_numpy(y_test).type(torch.Tensor)
y_train_gru = torch.from_numpy(y_train).type(torch.Tensor)
y_test_gru = torch.from_numpy(y_test).type(torch.Tensor)
# 将数据集制作成PyTorch的数据集
class CustomDataset(torch.utils.data.Dataset):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]
# 创建数据加载器
batch_size =512 # 设置你想要的批量大小
train_dataset = CustomDataset(x_train, y_train_lstm)
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

test_dataset = CustomDataset(x_test, y_test_lstm)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
num_epochs =50
input_dim = 8  # 输入特征的维度
d_model = 20 # Transformer模型的隐藏维度
nhead = 4 # 注意力头的数量
num_encoder_layers = 1 # 编码器层数
num_decoder_layers = 1  # 解码器层数
#batch_size = 32
dropout=0.2

class TransformerModel(nn.Module):
    def __init__(self, input_dim, d_model, nhead, num_encoder_layers, num_decoder_layers,dropout):
        super(TransformerModel, self).__init__()
        self.transformer = nn.Transformer(d_model=d_model, nhead=nhead, num_encoder_layers=num_encoder_layers,
                                          num_decoder_layers=num_decoder_layers,dropout=dropout)
        self.fc = nn.Linear(input_dim, d_model)
        self.output_layer = nn.Linear(d_model, 1)

    def forward(self, x):
        x = self.fc(x)
        x = self.transformer(x, x)  # Self-attention mechanism

        # 进行全局平均池化
        x = x.mean(dim=1)  # 在第二个维度上取平均，使其变成(batch_size, d_model)

        x = self.output_layer(x)
        return x

model =  TransformerModel(input_dim, d_model, nhead, num_encoder_layers, num_decoder_layers,dropout)

model.to(device)  # 将模型移动到GPU设备上
criterion = torch.nn.MSELoss()
optimiser = torch.optim.Adam(model.parameters(), lr=0.0001)
# 模型训练
hist = np.zeros(num_epochs)
val_hist= np.zeros(num_epochs)
start_time = time.time()
model.to(device)  # 将模型移动到GPU设备上
lstm = []
lambda_l2 = 0.0001# L2正则化系数
# 在外部循环之前创建一个空的张量
all_predictions = torch.empty((0, 1)).to(device)
all_predictions_test = torch.empty((0, 1)).to(device)
for t in range(num_epochs):
    model.train()  # 设置模型为训练模式
    total_loss = 0
    predictions_batch = torch.empty((0, 1)).to(device)
    predictions_test_batch= torch.empty((0, 1)).to(device)
    for batch_x, batch_y in train_loader:
        batch_x = batch_x.to(device)
        batch_y = batch_y.to(device)
        optimiser.zero_grad()
        y_train_pred = model(batch_x)
        loss = criterion(y_train_pred, batch_y)
        l2_reg = torch.tensor(0.).to(device)

        for param in model.parameters():
            l2_reg += torch.norm(param, p=2)
        loss += lambda_l2 * l2_reg

        loss.backward()
        optimiser.step()
        total_loss += loss.item()
        # 将每个批次的预测结果追加到predictions_batch中
        predictions_batch = torch.cat((predictions_batch, y_train_pred), dim=0)
    avg_loss = total_loss / len(train_loader)
    print("Epoch ", t, "MSE: ", avg_loss)
    hist[t] = avg_loss

    # 在测试集上计算损失值并记录到测试集损失值数组
    model.eval()  # 设置模型为评估模式
    total_test_loss = 0

    with torch.no_grad():
        for batch_x, batch_y in test_loader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)
            y_test_pred = model(batch_x)
            test_loss = criterion(y_test_pred, batch_y)
            total_test_loss += test_loss.item()
            # 将每个批次的预测结果追加到predictions_batch中
            predictions_test_batch = torch.cat((predictions_test_batch, y_test_pred), dim=0)
    avg_test_loss = total_test_loss / len(test_loader)
    val_hist[t] = avg_test_loss
# 在每个训练周期结束后，将predictions_batch的结果添加到all_predictions中
all_predictions = torch.cat((all_predictions, predictions_batch), dim=0)
all_predictions_test = torch.cat((all_predictions_test, predictions_test_batch), dim=0)
training_time = time.time() - start_time
print("Training time: {}".format(training_time))

fig2 = plt.figure()
ax2 = fig2.add_subplot(1, 1, 1)
# 绘制训练集损失值
ax2.plot(hist, label='Training Loss', color='royalblue')
# 绘制验证集损失值
ax2.plot(val_hist, label='Validation Loss', color='orange')
ax2.set_xlabel("Epoch", size=14)
ax2.set_ylabel("Loss", size=14)
ax2.set_title("Training and Validation Loss", size=14, fontweight='bold')

# 添加图例
ax2.legend()
plt.show()

# 显示图形
plt.show()


# 反归一化
y_train = scaler8.inverse_transform(y_train_lstm.cpu().detach().numpy())#lable
y_test = scaler8.inverse_transform(y_test_lstm.detach().cpu().numpy())
p_train=scaler8.inverse_transform(all_predictions.detach().cpu().numpy())
p_test=scaler8.inverse_transform(all_predictions_test.detach().cpu().numpy())
# 评估模型分数
def nse(y_tru, y_pre):
    if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
        result = 1 - torch.div(torch.sum(torch.square(y_tru - y_pre), dim=-1),
                               torch.sum(torch.square(y_tru - torch.mean(y_tru, dim=-1, keepdim=True))))
        return result
    elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
        result = 1 - np.divide(np.sum(np.square(y_tru - y_pre), axis=-1),
                               np.sum(np.square(y_tru - np.mean(y_tru, axis=-1))))
        return result
    else:
        return -1
def mae(y_tru, y_pre):
    if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
        return torch.mean(torch.abs(y_tru - y_pre), dim=-1)
    elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
        return np.mean(np.abs(y_tru - y_pre), axis=-1)
    else:
        return -1
def mape(y_tru, y_pre):
    if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
        return torch.mean(torch.abs(torch.div((y_tru - y_pre), y_tru)), dim=-1) * 100
    elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
        # y_tru[y_tru() == 0] = 1e-8
        return np.mean(np.abs(np.divide((y_tru - y_pre), y_tru)), axis=-1) * 100
    else:
        return -1
def rmse(y_tru, y_pre):
    if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
        return torch.sqrt(torch.mean(torch.square(y_tru - y_pre), dim=-1))
    elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
        return np.sqrt(np.mean(np.square(y_tru - y_pre), axis=-1))
    else:
        return -1
print("y",y_train.shape)
print("ytrainp",p_train.shape)
print(y_test.shape)
print('训练集NSE: %.2f NSE' % (nse(y_train[:, 0], p_train[:, 0])))
print('训练集MAE: %.2f MAE' % (mae(y_train[:, 0], p_train[:, 0])))
print('训练集MAPE: %.2f MAPE' % (mape(y_train[:, 0], p_train[:, 0])))
trainScore = math.sqrt(mean_squared_error(y_train[:, 0], p_train[:, 0]))
print('训练集RMSE: %.2f RMSE' % (trainScore))
print('测试集NSE: %.2f NSE' % (nse(y_test[:, 0], p_test[:, 0])))
print('测试集MAE: %.2f MAE' % (mae(y_test[:, 0], p_test[:, 0])))
print('测试集MAPE: %.2f MAPE' % (mape(y_test[:, 0], p_test[:, 0])))
testScore = math.sqrt(mean_squared_error(y_test[:, 0], p_test[:, 0]))
print('测试集RMSE: %.2f RMSE' % (testScore))
lstm.append(trainScore)
lstm.append(testScore)
lstm.append(training_time)
#新图
y_train_reshaped = y_train.reshape(y_train.shape[0])
y_test_reshaped = y_test.reshape(y_test.shape[0])
y_train_pred_reshaped = p_train.reshape(p_train.shape[0])
y_test_pred_reshaped = p_test.reshape(p_test.shape[0])
true =np.concatenate((y_train_reshaped[::4], y_test_reshaped[::4]))#整个真实值
pred_training =y_train_pred_reshaped[::4]#训练集预测
pred_testing = y_test_pred_reshaped[::4]#测试集预测
pred_training2 = y_train_pred_reshaped
pred_testing2 =y_test_pred_reshaped
x_train = np.arange(0, pred_training.shape[0])
x_test = np.arange(pred_training.shape[0], true.shape[0])
pred = np.concatenate((pred_training, pred_testing))#整个预测值
x = np.arange(0, true.shape[0])
fig = plt.figure(figsize=(16, 5))
gs = fig.add_gridspec(1, 3, hspace=0, wspace=0, width_ratios=[6, 5, 5])
(ax1, ax2, ax3) = gs.subplots(sharey='row')
fs = 14
ax1.set_xlim(0, true.shape[0])
ax1.set_ylim(10, 20)
ax1.set_yticks(np.arange(10, 20), labels=np.arange(10, 20), fontsize=fs)
ax1.set_xlabel('Time(Year)', fontsize=fs)
ax1.set_ylabel('Spring discharge($\\rm m^3/s$)', fontsize=fs)
ax1.xaxis.set_major_locator(ticker.FixedLocator(np.linspace(0, true.shape[0], 13)))
ax1.xaxis.set_major_formatter(ticker.NullFormatter())
ax1.xaxis.set_minor_locator(ticker.FixedLocator(np.arange(6, true.shape[0], 14.7)))
ax1.xaxis.set_minor_formatter(ticker.FixedFormatter(np.arange(1959, 1971, 1)))
ax1.tick_params(axis='x', which='minor', size=0, labelsize=fs)  # size=0 means bu xian shi xiao ke du
ax1.tick_params(axis='y', which='both', right=True)  # you mian ye xian shi ke du
ax1.tick_params(axis='both', which='both', direction='in')
ax1.plot(x, true, color='#c22f2f', label='Observed spring discharge', linewidth=1.5)
ax1.plot(x_train, pred_training, color='#1f70a9', label='Simulated value (training)', linewidth=1.5)
ax1.plot(x_test, pred_testing, color='#449945', label='Simulated value (testing)', linewidth=1.5)
ax1.text(11, 17, 'NSE=0.96', color='#1f70a9')
ax1.text(11 * 12-5, 17, 'NSE=0.92', color='#449945')
ax1.text(6, 19, '(a)')
ax1.legend(fontsize=13)  # 自由调整图例位

LR = linear_model.LinearRegression(fit_intercept=True)
LR.fit(y_train, pred_training2)
R2 = LR.score(y_train, pred_training2)
k = LR.coef_
b = LR.intercept_
ax2.scatter(pred_training, y_train[::4], color='royalblue', s=12)
ax2.set_xlim(10.5, 19.5)
x_tick = np.arange(11, 20)
ax2.set_xticks(x_tick, labels=x_tick, fontsize=fs)
ax2.set_xlabel('Simulated value in training period($\\rm m^3/s$)', fontsize=fs)
ax2.set_ylim(10, 20)
ax2.tick_params(axis='both', which='both', direction='in')
ax2.plot(LR.predict(y_train), y_train, color='red')
if b > 0:
    ax2.text(15, 12, '$y=%3.2fx+%3.2f$' % (k, b))
else:
    ax2.text(15, 12, '$y=%3.2fx%3.2f$' % (k, b))
ax2.text(15, 11, '$\\rm R^2=%3.2f$' % R2)
ax2.text(11, 19, '(b)')
ax2.axline((9.5, 9.5), (19.5, 19.5), linestyle='--', color='black')

LR = linear_model.LinearRegression(fit_intercept=True)
LR.fit(y_test, pred_testing2)
R2 = LR.score(y_test, pred_testing2)
k = LR.coef_
b = LR.intercept_
ax3.scatter(pred_testing, y_test[::4], color='royalblue', s=12)
ax3.set_xlim(10.5, 19.5)
ax2.set_ylim(10, 20)
x_tick = np.arange(11, 20)
ax3.set_xticks(x_tick, labels=x_tick, fontsize=fs)
ax3.set_xlabel('Simulated value in testing period($\\rm m^3/s$)', fontsize=fs)
ax3.tick_params(axis='both', which='both', direction='in')
ax3.plot(LR.predict(y_test), y_test, color='red')
if b > 0:
    ax3.text(15, 12, '$y=%3.2fx+%3.2f$' % (k, b))
else:
    ax3.text(15, 12, '$y=%3.2fx%3.2f$' % (k, b))
ax3.text(15, 11, '$\\rm R^2=%3.2f$' % R2)
ax3.text(11, 19, '(c)')
ax3.axline((9.5, 9.5), (19.5, 19.5), linestyle='--', color='black')
#plt.savefig("G:\\xiangmu\\1\\pic", bbox_inches='tight')

# 显示图形
plt.show()

