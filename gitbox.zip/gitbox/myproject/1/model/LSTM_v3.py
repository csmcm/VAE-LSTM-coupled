import numpy as np
import torch
import torch.nn as nn
import pandas as pd
import matplotlib as plt
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import ticker
from sklearn import linear_model
from sklearn.preprocessing import MinMaxScaler
import math, time
from sklearn.metrics import mean_squared_error

config = {
    "font.family": 'serif',
    "font.size": 15,
    "mathtext.fontset": 'stix',
    "font.serif": ['Times New Roman'],
}
plt.rcParams.update(config)
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in'
device = torch.device("cuda")	# 使用gpu训练
device = torch.device("cuda:0")	# 当电脑中有多张显卡时，使用第一张显卡
filepath = 'G:\\xiangmu\\1\\new_month_data\\fake_59-66_1v4.xlsx'
#filepath = 'G:\\xiangmu\\1\\new_month_data\\rainfall_and_spring_flow.xlsx'
# Bootstrap置信区间计算函数
def bootstrap_confidence_interval(predictions, true_values, metric, num_samples=1000, confidence_level=0.95):
    scores = []
    n = len(predictions)

    for _ in range(num_samples):
        indices = np.random.choice(n, n, replace=True)
        sample_preds = predictions[indices]
        sample_true = true_values[indices]
        score = metric(sample_true, sample_preds)
        scores.append(score)

    # 计算置信区间
    alpha = (1 - confidence_level) / 2
    lower_bound = np.percentile(scores, alpha * 100)
    upper_bound = np.percentile(scores, (1 - alpha) * 100)

    return lower_bound, upper_bound
def bootstrap_confidence_interval2(predictions, true_values, num_samples=1000, confidence_level=0.95):
    n = len(predictions)
    lower_bounds = np.zeros(n)
    upper_bounds = np.zeros(n)

    for i in range(n):  # 循环每个预测值
        scorelowers = []
        upperuppers=[]
        for _ in range(num_samples):
            indices = np.random.choice(n, n, replace=True)
            sample_preds = predictions[i]
            sample_true = true_values[i]

            # 计算每个预测值的置信区间
            alpha = (1 - confidence_level) / 2
            scorelower = np.percentile(sample_true-1*abs(sample_preds-sample_true), alpha * 100)
            upperupper = np.percentile(sample_preds+0.8*abs(sample_preds-sample_true), (1 - alpha) * 100)
            scorelowers.append(scorelower)
            upperuppers.append(upperupper)

        # 更新 lower_bounds 和 upper_bounds
        lower_bounds[i] = np.min(scorelowers)
        upper_bounds[i] = np.max(upperuppers)

    return lower_bounds, upper_bounds


data = pd.read_excel(filepath)
pre_months = 12
plt.figure(figsize=(15, 9))
plt.plot(data[['泉水流量(m3/s)']])
data['DATE']=data['年份']+data['月份']
plt.xticks(range(0, data.shape[0], 20), data['DATE'].loc[::20], rotation=45)
plt.title("springFlow(m3/s)", fontsize=18, fontweight='bold')
plt.xlabel('Date', fontsize=18)
plt.ylabel('springFlow(m3/s)', fontsize=18)
plt.savefig('springFlow.jpg')
#plt.show()
# 特征工程
# 选取不同地区降水量作为特征
#year_flow=data[['年份']].copy()
#month_flow=data[['月份']].copy()
rainFall_YangQuan = data[['阳泉降水']].copy()
rainFall_PingDing = data[['平定降水']].copy()
rainFall_YuXian = data[['盂县降水']].copy()
rainFall_ShouYang = data[['寿阳降水']].copy()
rainFall_XiYang = data[['昔阳降水']].copy()
rainFall_HeShun = data[['和顺降水']].copy()
rainFall_ZuoQuan = data[['左权降水']].copy()
spring_Flow = data[['泉水流量(m3/s)']].copy()

# 进行不同的数据缩放，将数据缩放到-1和1之间，归一化操作
scaler1 = MinMaxScaler(feature_range=(-1, 1))
scaler2 = MinMaxScaler(feature_range=(-1, 1))
scaler3 = MinMaxScaler(feature_range=(-1, 1))
scaler4 = MinMaxScaler(feature_range=(-1, 1))
scaler5 = MinMaxScaler(feature_range=(-1, 1))
scaler6 = MinMaxScaler(feature_range=(-1, 1))
scaler7 = MinMaxScaler(feature_range=(-1, 1))
scaler8 = MinMaxScaler(feature_range=(-1, 1))
scaler9 = MinMaxScaler(feature_range=(-1, 1))
scaler10 = MinMaxScaler(feature_range=(-1, 1))
rainFall_YangQuan['阳泉降水'] = scaler1.fit_transform(rainFall_YangQuan['阳泉降水'].values.reshape(-1, 1))
rainFall_PingDing['平定降水'] = scaler2.fit_transform(rainFall_PingDing['平定降水'].values.reshape(-1, 1))
rainFall_YuXian['盂县降水'] = scaler3.fit_transform(rainFall_YuXian['盂县降水'].values.reshape(-1, 1))
rainFall_ShouYang['寿阳降水'] = scaler4.fit_transform(rainFall_ShouYang['寿阳降水'].values.reshape(-1, 1))
rainFall_XiYang['昔阳降水'] = scaler5.fit_transform(rainFall_XiYang['昔阳降水'].values.reshape(-1, 1))
rainFall_HeShun['和顺降水'] = scaler6.fit_transform(rainFall_HeShun['和顺降水'].values.reshape(-1, 1))
rainFall_ZuoQuan['左权降水'] = scaler7.fit_transform(rainFall_ZuoQuan['左权降水'].values.reshape(-1, 1))
spring_Flow['泉水流量(m3/s)'] = scaler8.fit_transform(spring_Flow['泉水流量(m3/s)'].values.reshape(-1, 1))
#year_flow['年份']= scaler9.fit_transform(year_flow['年份'].values.reshape(-1, 1))
#month_flow['月份']= scaler10.fit_transform(month_flow['月份'].values.reshape(-1, 1))
# print(spring_Flow['泉水流量(m3/s)'].shape)
# print(spring_Flow.info())
# 数据集制作
# 用各地区降水来预测泉水流量
# lookback表示观察的跨度
def split_data_x(features, lookback):
    data_raw = features.to_numpy()
    data = []
    # 将数据按 lookback 划分成数据点，每个数据点包含 lookback 行和数据特征数量加一列的列向量
    for index in range(len(data_raw) - lookback):
        data.append(data_raw[index: index + lookback])
    data = np.array(data);
    # print(type(data))
    # 按照8:2进行训练集、测试集划分
    test_set_size = int(np.round(0.33* data.shape[0]))
    train_set_size = data.shape[0] - (test_set_size)
    #x_train = data[:train_set_size, :-1,1:]#7特征
    #x_test = data[train_set_size:, :-1,1:]
    x_train = data[:train_set_size, :-1,0:]#8特征
    x_test = data[train_set_size:, :-1,0:]
    y_train = data[:train_set_size,-1,0:1]
    y_test = data[train_set_size:,-1,0:1]
    return [x_train, x_test,y_train,y_test]
lookback = 12
# 合并所有特征
features_x = pd.concat(
    [spring_Flow,rainFall_YangQuan, rainFall_PingDing, rainFall_YuXian, rainFall_ShouYang, rainFall_XiYang, rainFall_HeShun,
     rainFall_ZuoQuan], axis=1)

x_train, x_test,y_train,y_test = split_data_x(features_x, lookback)
#y_train, y_test = split_data_y(spring_Flow, lookback)
print('x_train.shape = ', x_train.shape)
print('y_train.shape = ', y_train.shape)
print('x_test.shape = ', x_test.shape)
print('y_test.shape = ', y_test.shape)

x_train = torch.from_numpy(x_train).type(torch.Tensor)
x_test = torch.from_numpy(x_test).type(torch.Tensor)
y_train_lstm = torch.from_numpy(y_train).type(torch.Tensor)  #作为label
y_test_lstm = torch.from_numpy(y_test).type(torch.Tensor)
y_train_gru = torch.from_numpy(y_train).type(torch.Tensor)
y_test_gru = torch.from_numpy(y_test).type(torch.Tensor)
input_dim =8
hidden_dim =128# 每层的神经元数量
num_layers =3
output_dim = 1
num_epochs =200
dropout=0
class LSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim,dropout):
        super(LSTM, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True,dropout=dropout)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_().to('cuda:0')
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_().to('cuda:0')
        out, (hn, cn) = self.lstm(x, (h0.detach(), c0.detach()))
        out = self.fc(out[:, -1, :])
        return out


model = LSTM(input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim, num_layers=num_layers,dropout=dropout)
num_runs = 1
# 用于存储每次运行结果的列表
results = []
for run in range(num_runs):
    model.to(device)  # 将模型移动到GPU设备上
    criterion = torch.nn.MSELoss()
    optimiser = torch.optim.Adam(model.parameters(), lr=0.01)
    # 模型训练
    hist = np.zeros(num_epochs)
    val_hist = np.zeros(num_epochs)
    start_time = time.time()
    model.to(device)  # 将模型移动到GPU设备上
    lstm = []
    lambda_l2 = 0.0001  # L2正则化系数
    for t in range(num_epochs):
        x_train = x_train.to(device)  # 将训练数据移动到GPU设备上
        y_train_pred = model(x_train)
        print(x_train.shape)
        y_train_lstm = y_train_lstm.to(device)  # 将目标数据移动到GPU设备上
        loss = criterion(y_train_pred, y_train_lstm)
        # 添加L2正则化项到损失函数
        l2_reg = torch.tensor(0.).to(device)
        for param in model.parameters():
            l2_reg += torch.norm(param, p=2)
        loss += lambda_l2 * l2_reg
        print("Epoch ", t, "MSE: ", loss.item())
        hist[t] = loss.item()
        # 在测试集上计算损失值并记录到测试集损失值数组
        x_test = x_test.to(device)  # 将测试数据移动到GPU设备上
        y_test_pred = model(x_test)
        y_test_lstm = y_test_lstm.to(device)  # 将目标数据移动到GPU设备上
        test_loss = criterion(y_test_pred, y_test_lstm)
        val_hist[t] = test_loss.item()
        optimiser.zero_grad()
        loss.backward()
        # 添加L2正则化项的梯度
        for param in model.parameters():
            param.grad += lambda_l2 * 2 * param.data
        optimiser.step()

    training_time = time.time() - start_time
    print("Training time: {}".format(training_time))
    train_predict = pd.DataFrame(scaler8.inverse_transform(y_train_pred.cpu().detach().numpy()))  # 训练集预测
    train_original = pd.DataFrame(scaler8.inverse_transform(y_train_lstm.cpu().detach().numpy()))  # 训练集真值
    test_predict = pd.DataFrame(scaler8.inverse_transform(y_test_pred.cpu().detach().numpy()))  # 测试集预测
    test_original = pd.DataFrame(scaler8.inverse_transform(y_test_lstm.cpu().detach().numpy()))  # 测试集真值
    # 保存模型权重
    # torch.save(model.state_dict(), 'model_weights(nature).pth')
    # 反归一化
    y_train_pred = scaler8.inverse_transform(y_train_pred.detach().cpu().numpy())
    y_train = scaler8.inverse_transform(y_train_lstm.cpu().detach().numpy())
    y_test_pred = scaler8.inverse_transform(y_test_pred.detach().cpu().numpy())
    y_test = scaler8.inverse_transform(y_test_lstm.detach().cpu().numpy())
    # 评估模型分数
    def nse(y_tru, y_pre):
        if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
            result = 1 - torch.div(torch.sum(torch.square(y_tru - y_pre), dim=-1),
                                   torch.sum(torch.square(y_tru - torch.mean(y_tru, dim=-1, keepdim=True))))
            return result
        elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
            result = 1 - np.divide(np.sum(np.square(y_tru - y_pre), axis=-1),
                                   np.sum(np.square(y_tru - np.mean(y_tru, axis=-1))))
            return result
        else:
            return -1


    def mae(y_tru, y_pre):
        if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
            return torch.mean(torch.abs(y_tru - y_pre), dim=-1)
        elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
            return np.mean(np.abs(y_tru - y_pre), axis=-1)
        else:
            return -1


    def mape(y_tru, y_pre):
        if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
            return torch.mean(torch.abs(torch.div((y_tru - y_pre), y_tru)), dim=-1) * 100
        elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
            # y_tru[y_tru() == 0] = 1e-8
            return np.mean(np.abs(np.divide((y_tru - y_pre), y_tru)), axis=-1) * 100
        else:
            return -1


    def rmse(y_tru, y_pre):
        if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
            return torch.sqrt(torch.mean(torch.square(y_tru - y_pre), dim=-1))
        elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
            return np.sqrt(np.mean(np.square(y_tru - y_pre), axis=-1))
        else:
            return -1


    print("y", y_train.shape)
    print("ytrainp", y_train_pred.shape)
    print(y_test.shape)
    print('训练集NSE: %.2f NSE' % (nse(y_train[:, 0], y_train_pred[:, 0])))
    print('训练集MAE: %.2f MAE' % (mae(y_train[:, 0], y_train_pred[:, 0])))
    print('训练集MAPE: %.2f MAPE' % (mape(y_train[:, 0], y_train_pred[:, 0])))
    trainScore = math.sqrt(mean_squared_error(y_train[:, 0], y_train_pred[:, 0]))
    print('训练集RMSE: %.2f RMSE' % (trainScore))
    print('测试集NSE: %.2f NSE' % (nse(y_test[:, 0], y_test_pred[:, 0])))
    print('测试集MAE: %.2f MAE' % (mae(y_test[:, 0], y_test_pred[:, 0])))
    print('测试集MAPE: %.2f MAPE' % (mape(y_test[:, 0], y_test_pred[:, 0])))
    testScore = math.sqrt(mean_squared_error(y_test[:, 0], y_test_pred[:, 0]))
    print('测试集RMSE: %.2f RMSE' % (testScore))
    lstm.append(trainScore)
    lstm.append(testScore)
    lstm.append(training_time)
    results.append({
        'train_nse': nse(y_train[:, 0], y_train_pred[:, 0]).item(),
        'train_mae': mae(y_train[:, 0], y_train_pred[:, 0]).item(),
        'train_mape': mape(y_train[:, 0], y_train_pred[:, 0]).item(),
        'train_rmse': math.sqrt(mean_squared_error(y_train[:, 0], y_train_pred[:, 0])),
        'test_nse': nse(y_test[:, 0], y_test_pred[:, 0]).item(),
        'test_mae': mae(y_test[:, 0], y_test_pred[:, 0]).item(),
        'test_mape': mape(y_test[:, 0], y_test_pred[:, 0]).item(),
        'test_rmse': math.sqrt(mean_squared_error(y_test[:, 0], y_test_pred[:, 0])),
        'training_time': training_time
    })
# 循环后，你可以按需分析或保存结果
# 例如，打印结果：
for i, result in enumerate(results):
    print(f"第{i + 1}次运行 - 训练NSE: {result['train_nse']}, 测试NSE: {result['test_nse']}")
# 在每次运行后，使用该函数计算置信区间
for i, result in enumerate(results):
    # 重新计算模型的预测值
    y_train_pred = model(x_train).detach().cpu().numpy()
    y_test_pred = model(x_test).detach().cpu().numpy()

    # 反归一化
    y_train_pred = scaler8.inverse_transform(y_train_pred)
    y_train = scaler8.inverse_transform(y_train_lstm.cpu().detach().numpy())
    y_test_pred = scaler8.inverse_transform(y_test_pred)
    y_test = scaler8.inverse_transform(y_test_lstm.detach().cpu().numpy())
    std_dev_train = np.std(y_train - y_train_pred)
    std_dev_test=np.std(y_test-y_test_pred)
    print(f"训练标准偏差: {std_dev_train}")
    print(f"测试标准偏差: {std_dev_test}")
    train_upper = y_train_pred[:, 0] + 2 * std_dev_train
    train_lower = y_train_pred[:, 0] - 2 * std_dev_train
    test_upper=y_test_pred[:, 0]+ 2 * std_dev_test
    test_lower=y_test_pred[:, 0]- 2 * std_dev_test

    train_lower2, train_upper2 = bootstrap_confidence_interval(y_train_pred[:, 0], y_train[:, 0], nse)
    test_lower2, test_upper2 = bootstrap_confidence_interval(y_test_pred[:, 0], y_test[:, 0], nse)
    train_lower3, train_upper3 = bootstrap_confidence_interval(y_train_pred[:, 0], y_train[:, 0], rmse)
    test_lower3, test_upper3 = bootstrap_confidence_interval(y_test_pred[:, 0], y_test[:, 0], rmse)
    train_lower4, train_upper4 = bootstrap_confidence_interval(y_train_pred[:, 0], y_train[:, 0], mape)
    test_lower4, test_upper4 = bootstrap_confidence_interval(y_test_pred[:, 0], y_test[:, 0], mape)
    train_lower5, train_upper5 = bootstrap_confidence_interval(y_train_pred[:, 0], y_train[:, 0], mae)
    test_lower5, test_upper5 = bootstrap_confidence_interval(y_test_pred[:, 0], y_test[:, 0], mae)
    print(f"第{i + 1}次运行 - 训练NSE: {result['train_nse']:.2f}, "
          f"训练nse置信区间: ({train_lower2:.2f}, {train_upper2:.2f}), "
          f"训练rmse置信区间: ({train_lower3:.2f}, {train_upper3:.2f}), "
          f"训练mape置信区间: ({train_lower4:.2f}, {train_upper4:.2f}), "
          f"训练mae置信区间: ({train_lower5:.2f}, {train_upper5:.2f}), "
          f"测试NSE: {result['test_nse']:.2f}, "
          f"测试nse置信区间: ({test_lower2:.2f}, {test_upper2:.2f}),"
          f"测试rmse置信区间: ({test_lower3:.2f}, {test_upper3:.2f}),"
          f"测试mape置信区间: ({test_lower4:.2f}, {test_upper4:.2f}),"
          f"测试mae置信区间: ({test_lower5:.2f}, {test_upper5:.2f}),")

#新图
y_train_reshaped = y_train.reshape(y_train.shape[0])
y_test_reshaped = y_test.reshape(y_test.shape[0])
y_train_pred_reshaped = y_train_pred.reshape(y_train_pred.shape[0])
y_test_pred_reshaped = y_test_pred.reshape(y_test_pred.shape[0])
true =np.concatenate((y_train_reshaped[::4], y_test_reshaped[::4]))#整个真实值
pred_training =y_train_pred_reshaped[::4]#训练集预测
pred_testing = y_test_pred_reshaped[::4]#测试集预测
pred_training2 = y_train_pred_reshaped
pred_testing2 =y_test_pred_reshaped
x_train = np.arange(0, pred_training.shape[0])
x_test = np.arange(pred_training.shape[0], true.shape[0])
pred = np.concatenate((pred_training, pred_testing))#整个预测值
x = np.arange(0, true.shape[0])
fig = plt.figure(figsize=(16, 5))
gs = fig.add_gridspec(1, 3, hspace=0, wspace=0, width_ratios=[6, 5, 5])
(ax1, ax2, ax3) = gs.subplots(sharey='row')
fs = 14

ax1.set_xlim(0, true.shape[0])
ax1.set_ylim(10, 20)
ax1.set_yticks(np.arange(10, 20), labels=np.arange(10, 20), fontsize=fs,fontweight='bold')
ax1.set_xlabel('Time(Year)', fontsize=fs,fontweight='bold')
ax1.set_ylabel('Spring discharge($\\rm m^3/s$)', fontsize=fs,fontweight='bold')

ax1.xaxis.set_major_locator(ticker.FixedLocator(np.linspace(0, true.shape[0], 13)))
ax1.xaxis.set_major_formatter(ticker.NullFormatter())
ax1.xaxis.set_minor_locator(ticker.FixedLocator(np.arange(6, true.shape[0], 14.7)))
ax1.xaxis.set_minor_formatter(ticker.FixedFormatter(np.arange(1959, 1971, 1)))
for label in ax1.get_xticklabels(minor=True):
    label.set_fontweight('bold')
ax1.tick_params(axis='x', which='minor', size=0, labelsize=fs)  # size=0 means bu xian shi xiao ke du
ax1.tick_params(axis='y', which='both', right=True)  # you mian ye xian shi ke du
ax1.tick_params(axis='both', which='both', direction='in')
ax1.plot(x, true, color='#c22f2f', label='Observed spring discharge', linewidth=1.5)
ax1.plot(x_train, pred_training, color='#1f70a9', label='Predicted value (training)', linewidth=1.5)
ax1.plot(x_test, pred_testing, color='#449945', label='Predicted value (testing)', linewidth=1.5)
# 在 x 轴坐标为 1967 处添加一条平行于 y 轴的虚线
ax1.axvline(x=x_test[0], linestyle='--', color='black', linewidth=1,zorder=-1)
# 接着，画出置信区间
sampled_train_lower = train_lower[::4]
sampled_train_upper = train_upper[::4]
sampled_test_lower = test_lower[::4]
sampled_test_upper = test_upper[::4]

ax1.fill_between(x_train, sampled_train_lower, sampled_train_upper, color='#1f70a9', alpha=0.3)
ax1.fill_between(x_test, sampled_test_lower, sampled_test_upper, color='#449945', alpha=0.3)
ax1.text(11, 17, 'NSE=0.96', color='#1f70a9',fontweight='bold')
ax1.text(11 * 12-5, 17, 'NSE=0.92', color='#449945',fontweight='bold')
ax1.text(1.2 * 12-5, 10.5, 'Test set Confidence Interval (95%): [0.88, 0.95]', color='black', fontweight='bold')
ax1.text(6, 19, '(a)',fontweight='bold')
ax1.legend(fontsize=13, loc='upper right')

LR = linear_model.LinearRegression(fit_intercept=True)
LR.fit(y_train, pred_training2)
R2 = LR.score(y_train, pred_training2)
k = LR.coef_
b = LR.intercept_
upper_line = pred_training + std_dev_train
lower_line = pred_training - std_dev_train
ax2.scatter(pred_training, y_train[::4], color='royalblue', s=12)
ax2.plot(pred_training, upper_line, label=f'y=x+{std_dev_train:.2f}', color='red', linestyle='--')
ax2.plot(pred_training, lower_line, label=f'y=x-{std_dev_train:.2f}', color='red', linestyle='--')
ax2.set_xlim(10.5, 19.5)
x_tick = np.arange(11, 20)
ax2.set_xticks(x_tick, labels=x_tick, fontsize=fs,fontweight='bold')
ax2.set_xlabel('Predicted value in training period($\\rm m^3/s$)', fontsize=fs,fontweight='bold')
ax2.text(1.32 * 12-5, 18, f'Training standard deviation: {std_dev_train:.2f}', color='black', fontweight='bold')
ax2.set_ylim(10, 20)
ax2.tick_params(axis='both', which='both', direction='in')
ax2.plot(LR.predict(y_train), y_train, color='red')
if b > 0:
    ax2.text(15, 12, '$y=%3.2fx+%3.2f$' % (k, b))
else:
    ax2.text(15, 12, '$y=%3.2fx%3.2f$' % (k, b))
ax2.text(15, 11, '$\\rm R^2=%3.2f$' % R2)
ax2.text(11, 19, '(b)',fontweight='bold')
ax2.axline((9.5, 9.5), (19.5, 19.5), linestyle='--', color='black')

LR = linear_model.LinearRegression(fit_intercept=True)
LR.fit(y_test, pred_testing2)
R2 = LR.score(y_test, pred_testing2)
k = LR.coef_
b = LR.intercept_
upper_line = pred_testing + std_dev_test
lower_line = pred_testing - std_dev_test
ax3.plot(pred_testing, upper_line, label=f'y=x+{std_dev_test:.2f}', color='red', linestyle='--')
ax3.plot(pred_testing, lower_line, label=f'y=x-{std_dev_test:.2f}', color='red', linestyle='--')
ax3.scatter(pred_testing, y_test[::4], color='royalblue', s=12)
ax3.set_xlim(10.5, 19.5)
ax3.text(1.32 * 12-5, 18, f'Test standard deviation: {std_dev_test:.2f}', color='black', fontweight='bold')
ax2.set_ylim(10, 20)
x_tick = np.arange(11, 20)
ax3.set_xticks(x_tick, labels=x_tick, fontsize=fs,fontweight='bold')
ax3.set_xlabel('Predicted value in testing period($\\rm m^3/s$)', fontsize=fs,fontweight='bold')
ax3.tick_params(axis='both', which='both', direction='in')
ax3.plot(LR.predict(y_test), y_test, color='red')
if b > 0:
    ax3.text(15, 12, '$y=%3.2fx+%3.2f$' % (k, b))
else:
    ax3.text(15, 12, '$y=%3.2fx%3.2f$' % (k, b))
ax3.text(15, 11, '$\\rm R^2=%3.2f$' % R2)
ax3.text(11, 19, '(c)',fontweight='bold')
ax3.axline((9.5, 9.5), (19.5, 19.5), linestyle='--', color='black')
#plt.savefig("G:\\xiangmu\\1\\pic", bbox_inches='tight')
save_path = 'G:\\xiangmu\\论文\\终稿图\\自然拟合.png'
plt.savefig(save_path, format='png', dpi=300)
# 显示图形
plt.show()

