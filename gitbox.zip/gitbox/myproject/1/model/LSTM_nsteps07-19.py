import numpy as np
import torch
import torch.nn as nn
import pandas as pd
import matplotlib as plt
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import ticker
from sklearn import linear_model
from sklearn.preprocessing import MinMaxScaler
import math, time
from sklearn.metrics import mean_squared_error

config = {
    "font.family": 'serif',
    "font.size": 15,
    "mathtext.fontset": 'stix',
    "font.serif": ['Times New Roman'],
}
plt.rcParams.update(config)
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in'
device = torch.device("cuda")	# 使用gpu训练
device = torch.device("cuda:0")	# 当电脑中有多张显卡时，使用第一张显卡
filepath = 'G:\\xiangmu\\1\\new_month_data\\fake_07-19_1v7.xlsx'
#filepath = 'G:\\xiangmu\\1\\new_month_data\\rainfall_and_spring_flow.xlsx'

data = pd.read_excel(filepath)
pre_months = 12
# print(data)
# print(data.shape)
#data=data.diff().dropna() #一阶差分
#sns.set_style("darkgrid")
plt.figure(figsize=(15, 9))
plt.plot(data[['泉水流量(m3/s)']])
data['DATE']=data['年份']+data['月份']
plt.xticks(range(0, data.shape[0], 20), data['DATE'].loc[::20], rotation=45)
plt.title("springFlow(m3/s)", fontsize=18, fontweight='bold')
plt.xlabel('Date', fontsize=18)
plt.ylabel('springFlow(m3/s)', fontsize=18)
plt.savefig('springFlow.jpg')
#plt.show()
# 特征工程
# 选取不同地区降水量作为特征
#year_flow=data[['年份']].copy()
#month_flow=data[['月份']].copy()
rainFall_YangQuan = data[['阳泉降水']].copy()
rainFall_PingDing = data[['平定降水']].copy()
rainFall_YuXian = data[['盂县降水']].copy()
rainFall_ShouYang = data[['寿阳降水']].copy()
rainFall_XiYang = data[['昔阳降水']].copy()
rainFall_HeShun = data[['和顺降水']].copy()
rainFall_ZuoQuan = data[['左权降水']].copy()
spring_Flow = data[['泉水流量(m3/s)']].copy()

# 进行不同的数据缩放，将数据缩放到-1和1之间，归一化操作
scaler1 = MinMaxScaler(feature_range=(-1, 1))
scaler2 = MinMaxScaler(feature_range=(-1, 1))
scaler3 = MinMaxScaler(feature_range=(-1, 1))
scaler4 = MinMaxScaler(feature_range=(-1, 1))
scaler5 = MinMaxScaler(feature_range=(-1, 1))
scaler6 = MinMaxScaler(feature_range=(-1, 1))
scaler7 = MinMaxScaler(feature_range=(-1, 1))
scaler8 = MinMaxScaler(feature_range=(-1, 1))
scaler9 = MinMaxScaler(feature_range=(-1, 1))
scaler10 = MinMaxScaler(feature_range=(-1, 1))
rainFall_YangQuan['阳泉降水'] = scaler1.fit_transform(rainFall_YangQuan['阳泉降水'].values.reshape(-1, 1))
rainFall_PingDing['平定降水'] = scaler2.fit_transform(rainFall_PingDing['平定降水'].values.reshape(-1, 1))
rainFall_YuXian['盂县降水'] = scaler3.fit_transform(rainFall_YuXian['盂县降水'].values.reshape(-1, 1))
rainFall_ShouYang['寿阳降水'] = scaler4.fit_transform(rainFall_ShouYang['寿阳降水'].values.reshape(-1, 1))
rainFall_XiYang['昔阳降水'] = scaler5.fit_transform(rainFall_XiYang['昔阳降水'].values.reshape(-1, 1))
rainFall_HeShun['和顺降水'] = scaler6.fit_transform(rainFall_HeShun['和顺降水'].values.reshape(-1, 1))
rainFall_ZuoQuan['左权降水'] = scaler7.fit_transform(rainFall_ZuoQuan['左权降水'].values.reshape(-1, 1))
spring_Flow['泉水流量(m3/s)'] = scaler8.fit_transform(spring_Flow['泉水流量(m3/s)'].values.reshape(-1, 1))
#year_flow['年份']= scaler9.fit_transform(year_flow['年份'].values.reshape(-1, 1))
#month_flow['月份']= scaler10.fit_transform(month_flow['月份'].values.reshape(-1, 1))
# print(spring_Flow['泉水流量(m3/s)'].shape)
# print(spring_Flow.info())
# 数据集制作
# 用各地区降水来预测泉水流量
# lookback表示观察的跨度
def split_data_x(features, lookback,forecast_steps):
    data_raw = features.to_numpy()
    data = []
    # 将数据按 lookback 划分成数据点，每个数据点包含 lookback 行和数据特征数量加一列的列向量
    for index in range(len(data_raw) - lookback - forecast_steps + 1):
        data.append(data_raw[index: index + lookback + forecast_steps])
    data = np.array(data);
    # print(type(data))
    # 按照8:2进行训练集、测试集划分
    test_set_size = int(np.round(0.33* data.shape[0]))
    train_set_size = data.shape[0] - (test_set_size)
    x_train = data[:train_set_size, :-forecast_steps, 0:]#8特征，2代表滑动窗口是0到倒数第一位为train，3代表特征个数
    x_test = data[train_set_size:, :-forecast_steps, 0:]
    y_train = data[:train_set_size, -forecast_steps:, 0:1]  # 选择未来多个时间步的流量作为目标值
    y_test = data[train_set_size:, -forecast_steps:, 0:1]
    return [x_train, x_test,y_train,y_test]
lookback = 96
forecast_steps = 48# 修改为需要预测的未来时间步数
# 合并所有特征
features_x = pd.concat(
    [spring_Flow,rainFall_YangQuan, rainFall_PingDing, rainFall_YuXian, rainFall_ShouYang, rainFall_XiYang, rainFall_HeShun,
     rainFall_ZuoQuan], axis=1)

x_train, x_test,y_train,y_test = split_data_x(features_x, lookback,forecast_steps)
#y_train, y_test = split_data_y(spring_Flow, lookback)
print('x_train.shape = ', x_train.shape)
print('y_train.shape = ', y_train.shape)
print('x_test.shape = ', x_test.shape)
print('y_test.shape = ', y_test.shape)

x_train = torch.from_numpy(x_train).type(torch.Tensor)
x_test = torch.from_numpy(x_test).type(torch.Tensor)
y_train_lstm = torch.from_numpy(y_train).type(torch.Tensor)  #作为label
y_test_lstm = torch.from_numpy(y_test).type(torch.Tensor)
y_train_gru = torch.from_numpy(y_train).type(torch.Tensor)
y_test_gru = torch.from_numpy(y_test).type(torch.Tensor)
input_dim =8
hidden_dim =128# 每层的神经元数量
num_layers =3
output_dim =48
num_epochs =200
#batch_size = 32
dropout=0
class LSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim,dropout):
        super(LSTM, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True,dropout=dropout)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_().to('cuda:0')
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_().to('cuda:0')
        out, (hn, cn) = self.lstm(x, (h0.detach(), c0.detach()))
        out = self.fc(out[:, -1, :])
        return out


model = LSTM(input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim, num_layers=num_layers,dropout=dropout)

model.to(device)  # 将模型移动到GPU设备上
criterion = torch.nn.MSELoss()
optimiser = torch.optim.Adam(model.parameters(), lr=0.01)
# 模型训练
hist = np.zeros(num_epochs)
val_hist= np.zeros(num_epochs)
start_time = time.time()
model.to(device)  # 将模型移动到GPU设备上
lstm = []
lambda_l2 = 0# L2正则化系数
for t in range(num_epochs):
    x_train = x_train.to(device)  # 将训练数据移动到GPU设备上
    y_train_pred = model(x_train)#训练后出来steps个预测结果
    y_train_lstm = y_train_lstm.to(device)
    y_train_lstm_squeezed = torch.squeeze(y_train_lstm, dim=-1)
    loss = criterion(y_train_pred, y_train_lstm_squeezed)#预测结果与标签做loss

    # 添加L2正则化项到损失函数
    l2_reg = torch.tensor(0.).to(device)
    for param in model.parameters():
       l2_reg += torch.norm(param, p=2)
    loss += lambda_l2 * l2_reg
    print("Epoch ", t, "MSE: ", loss.item())
    hist[t] = loss.item()
    # 在测试集上计算损失值并记录到测试集损失值数组
    x_test = x_test.to(device)  # 将测试数据移动到GPU设备上
    y_test_pred = model(x_test)
    y_test_lstm = y_test_lstm.to(device)
    y_tset_lstm_squeezed = torch.squeeze(y_test_lstm, dim=-1)
    test_loss = criterion(y_test_pred, y_tset_lstm_squeezed)
    val_hist[t] = test_loss.item()
    optimiser.zero_grad()
    loss.backward()
    # 添加L2正则化项的梯度
    for param in model.parameters():
       param.grad += lambda_l2 * 2 * param.data
    optimiser.step()

training_time = time.time() - start_time
print("Training time: {}".format(training_time))
train_predict = pd.DataFrame(scaler8.inverse_transform(y_train_pred.cpu().detach().numpy()))#训练集预测
train_original = pd.DataFrame(scaler8.inverse_transform(y_train_lstm_squeezed.cpu().detach().numpy()))#训练集真值
test_predict = pd.DataFrame(scaler8.inverse_transform(y_test_pred.cpu().detach().numpy()))#测试集预测
test_original = pd.DataFrame(scaler8.inverse_transform(y_tset_lstm_squeezed.cpu().detach().numpy()))#测试集真值
# 保存模型权重
#torch.save(model.state_dict(), 'model_weights(nature).pth')
# 模型结果可视化
# 第一个图
# 第二个图
fig2 = plt.figure()
ax2 = fig2.add_subplot(1, 1, 1)

# 绘制训练集损失值
ax2.plot(hist, label='Training Loss', color='royalblue')
# 绘制验证集损失值
ax2.plot(val_hist, label='Validation Loss', color='orange')

ax2.set_xlabel("Epoch", size=14)
ax2.set_ylabel("Loss", size=14)
ax2.set_title("Training and Validation Loss", size=14, fontweight='bold')

# 添加图例
ax2.legend()
plt.show()

# 显示图形
plt.show()


# 反归一化
y_train_pred = scaler8.inverse_transform(y_train_pred.detach().cpu().numpy())
y_train = scaler8.inverse_transform(y_train_lstm_squeezed.cpu().detach().numpy())
y_test_pred = scaler8.inverse_transform(y_test_pred.detach().cpu().numpy())
y_test = scaler8.inverse_transform(y_tset_lstm_squeezed.detach().cpu().numpy())
# 评估模型分数
def nse(y_tru, y_pre):
    if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
        result = 1 - torch.div(torch.sum(torch.square(y_tru - y_pre), dim=-1),
                               torch.sum(torch.square(y_tru - torch.mean(y_tru, dim=-1, keepdim=True))))
        return result
    elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
        result = 1 - np.divide(np.sum(np.square(y_tru - y_pre), axis=-1),
                               np.sum(np.square(y_tru - np.mean(y_tru, axis=-1))))
        return result
    else:
        return -1
def mae(y_tru, y_pre):
    if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
        return torch.mean(torch.abs(y_tru - y_pre), dim=-1)
    elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
        return np.mean(np.abs(y_tru - y_pre), axis=-1)
    else:
        return -1
def mape(y_tru, y_pre):
    if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
        return torch.mean(torch.abs(torch.div((y_tru - y_pre), y_tru)), dim=-1) * 100
    elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
        # y_tru[y_tru() == 0] = 1e-8
        return np.mean(np.abs(np.divide((y_tru - y_pre), y_tru)), axis=-1) * 100
    else:
        return -1
def rmse(y_tru, y_pre):
    if type(y_tru) is torch.Tensor and type(y_pre) is torch.Tensor:
        return torch.sqrt(torch.mean(torch.square(y_tru - y_pre), dim=-1))
    elif type(y_tru) is np.ndarray and type(y_pre) is np.ndarray:
        return np.sqrt(np.mean(np.square(y_tru - y_pre), axis=-1))
    else:
        return -1
print('训练集NSE: %.2f NSE' % (nse(y_train[:, 0], y_train_pred[:, 0])))
print('训练集MAE: %.2f MAE' % (mae(y_train[:, 0], y_train_pred[:, 0])))
print('训练集MAPE: %.2f MAPE' % (mape(y_train[:, 0], y_train_pred[:, 0])))
trainScore = math.sqrt(mean_squared_error(y_train[:, 0], y_train_pred[:, 0]))
print('训练集RMSE: %.2f RMSE' % (trainScore))
print('测试集NSE: %.2f NSE' % (nse(y_test[:, 0], y_test_pred[:, 0])))
print('测试集MAE: %.2f MAE' % (mae(y_test[:, 0], y_test_pred[:, 0])))
print('测试集MAPE: %.2f MAPE' % (mape(y_test[:, 0], y_test_pred[:, 0])))
testScore = math.sqrt(mean_squared_error(y_test[:, 0], y_test_pred[:, 0]))
print('测试集RMSE: %.2f RMSE' % (testScore))
lstm.append(trainScore)
lstm.append(testScore)
lstm.append(training_time)

