import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np
import random
# 定义数据集类
class RainfallAndSpringFlowDataset(Dataset):
    def __init__(self, path):
        data = pd.read_excel(path)
        self.scaler = StandardScaler()
        self.data = self.scaler.fit_transform(data.values)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return torch.Tensor(self.data[idx])

    def sample(self, n):
        return torch.Tensor(random.sample(self.data.tolist(), n))

# 定义 VAE 模型类
class VAE(nn.Module):
    def __init__(self, input_dim, hidden_dim, latent_dim):
        super(VAE, self).__init__()

        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim * 2)
        )

        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim)
        )

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        z = mu + eps * std
        return z

    def forward(self, x):
        mu_logvar = self.encoder(x)
        mu = mu_logvar[:, :latent_dim]
        logvar = mu_logvar[:, latent_dim:]
        z = self.reparameterize(mu, logvar)
        recon_x = self.decoder(z)
        return recon_x, mu, logvar

# 训练函数
def train(model, dataset, epochs, batch_size, learning_rate, print_every=50):
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    for epoch in range(1, epochs+1):
        model.train()
        train_loss = 0
        data_loader = DataLoader(dataset, batch_size=1, shuffle=True)  # 每次只加载一行数据
        for i, x in enumerate(data_loader):
            optimizer.zero_grad()
            recon_x, mu, logvar = model(x)
            recon_loss = nn.MSELoss()(recon_x, x)
            kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
            loss = recon_loss + kl_loss
            loss.backward()
            train_loss += loss.item()
            optimizer.step()

            if (i+1) % print_every == 0:
                print('Epoch [{}/{}], Step [{}/{}], Reconstruction Loss: {:.4f}, KL Divergence Loss: {:.4f}'
                      .format(epoch, epochs, i+1, len(dataset), recon_loss.item(), kl_loss.item()))

        print('Epoch [{}/{}], Average Train Loss: {:.4f}'.format(epoch, epochs, train_loss/len(dataset)))

# 修改生成样本函数
def generate_samples(model, dataset, n_samples):
    model.eval()
    samples = []
    for i in range(n_samples):
        sample = model.decoder(torch.randn(1, latent_dim)).detach().numpy()
        samples.append(sample)
    samples = np.concatenate(samples, axis=0)
    return dataset.scaler.inverse_transform(samples)

# 参数设置
input_dim = 10
hidden_dim = 16
latent_dim = 4
batch_size = 32
learning_rate = 0.001
epochs = 100

