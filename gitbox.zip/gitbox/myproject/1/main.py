import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from xlsxwriter import Workbook
from model.VAE3 import RainfallAndSpringFlowDataset, VAE, train, generate_samples, input_dim, hidden_dim, learning_rate, \
    epochs, batch_size, latent_dim

if __name__ == '__main__':
    def run_vae(data_path, output_path, input_dim=10, hidden_dim=32, latent_dim=4, batch_size=10, learning_rate=0.001,
                epochs=200):
        # 加载数据集
        dataset = RainfallAndSpringFlowDataset(data_path)
        # 初始化模型
        model = VAE(input_dim, hidden_dim, latent_dim)
        # 训练模型
        train(model, dataset, epochs, batch_size, learning_rate)
        # 生成样本
        generated_samples = generate_samples(model, dataset, 52)
        # 将生成的合成数据转换为DataFrame格式
        synthetic_data = pd.DataFrame(generated_samples,
                                      columns=["年份", "月份", "阳泉降水", "平定降水", "盂县降水", "寿阳降水",
                                               "昔阳降水", "和顺降水", "左权降水", "泉水流量(m3/s)"])
        synthetic_data = synthetic_data.round(1)
        # 返回合成数据的DataFrame
        return synthetic_data


    data_paths1 = ['G:\\xiangmu\\1\\data\\59-66\\59-66_1.xlsx', 'G:\\xiangmu\\1\\data\\59-66\\59-66_2.xlsx', 'G:\\xiangmu\\1\\data\\59-66\\59-66_3.xlsx'
                  ,'G:\\xiangmu\\1\\data\\59-66\\59-66_4.xlsx','G:\\xiangmu\\1\\data\\59-66\\59-66_5.xlsx','G:\\xiangmu\\1\\data\\59-66\\59-66_6.xlsx',
                  'G:\\xiangmu\\1\\data\\59-66\\59-66_7.xlsx','G:\\xiangmu\\1\\data\\59-66\\59-66_8.xlsx','G:\\xiangmu\\1\\data\\59-66\\59-66_9.xlsx',
                  'G:\\xiangmu\\1\\data\\59-66\\59-66_10.xlsx','G:\\xiangmu\\1\\data\\59-66\\59-66_11.xlsx','G:\\xiangmu\\1\\data\\59-66\\59-66_12.xlsx']
    output_pathx = 'G:\\xiangmu\\1\\new_month_data\\59-70auto4.xlsx'
    output_path1 = 'G:\\xiangmu\\1\\ye\\nature100.xlsx'
    data_paths4 = ['G:\\xiangmu\\1\\data\\71-06\\1.xlsx', 'G:\\xiangmu\\1\\data\\71-06\\2.xlsx',
                   'G:\\xiangmu\\1\\data\\71-06\\3.xlsx'
        , 'G:\\xiangmu\\1\\data\\71-06\\4.xlsx', 'G:\\xiangmu\\1\\data\\71-06\\5.xlsx',
                   'G:\\xiangmu\\1\\data\\71-06\\6.xlsx',
                   'G:\\xiangmu\\1\\data\\71-06\\7.xlsx', 'G:\\xiangmu\\1\\data\\71-06\\8.xlsx',
                   'G:\\xiangmu\\1\\data\\71-06\\9.xlsx',
                   'G:\\xiangmu\\1\\data\\71-06\\10.xlsx', 'G:\\xiangmu\\1\\data\\71-06\\11.xlsx',
                   'G:\\xiangmu\\1\\data\\71-06\\12.xlsx']
    output_path4 = 'G:\\xiangmu\\1\\new_month_data\\71-06auto4.xlsx'
    data_paths5 = ['G:\\xiangmu\\1\\data\\07-19\\1.xlsx', 'G:\\xiangmu\\1\\data\\07-19\\2.xlsx',
                   'G:\\xiangmu\\1\\data\\07-19\\3.xlsx'
        , 'G:\\xiangmu\\1\\data\\07-19\\4.xlsx', 'G:\\xiangmu\\1\\data\\07-19\\5.xlsx',
                   'G:\\xiangmu\\1\\data\\07-19\\6.xlsx',
                   'G:\\xiangmu\\1\\data\\07-19\\7.xlsx', 'G:\\xiangmu\\1\\data\\07-19\\8.xlsx',
                   'G:\\xiangmu\\1\\data\\07-19\\9.xlsx',
                   'G:\\xiangmu\\1\\data\\07-19\\10.xlsx', 'G:\\xiangmu\\1\\data\\07-19\\11.xlsx',
                   'G:\\xiangmu\\1\\data\\07-19\\12.xlsx']
    output_path5 = 'G:\\xiangmu\\1\\new_month_data\\07-19auto4.xlsx'
    # 创建空的DataFrame对象
    all_data = pd.DataFrame()

    # 对于每个数据文件调用run_vae函数，并将数据添加到all_data中
    for data_paths5 in data_paths5:
        # 运行run_vae函数生成数据
        generated_data = run_vae(data_paths5,output_path5)
        # 将生成的数据添加到all_data中
        all_data = pd.concat([all_data, generated_data])

    # 将合成数据保存到Excel文件中
    writer = pd.ExcelWriter(output_path5)
    all_data.to_excel(writer, index=False)
    writer.close()
